<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
session_start();
// Include the configuration file 
require_once 'config.php';

// Include the database connection file 
$country = "Other";
include_once 'dbConnect.php';

// Include the Stripe PHP library 
require_once 'stripe-php/init.php';



// Set API key 
\Stripe\Stripe::setApiKey(STRIPE_API_KEY);

// Retrieve JSON from POST body 
$jsonStr = file_get_contents('php://input');
$jsonObj = json_decode($jsonStr);

// Get user ID from current SESSION 
$userID = isset($_SESSION['user_id']) ? $_SESSION['user_id'] : 1;
echo $siteId = $_SESSION['siteId'];
$count_site =  $_SESSION["count_site"];

 

include_once 'dbConnect.php';
// die;
// Include the Stripe PHP library 
require_once 'stripe-php/init.php';
\Stripe\Stripe::setApiKey(STRIPE_API_KEY);
// $subsc_id_url = $_REQUEST['sid'];




if ($jsonObj->request_type == 'create_customer_subscription') {
    $subscr_plan_id = !empty($jsonObj->subscr_plan_id) ? $jsonObj->subscr_plan_id : '';

    $name = !empty($jsonObj->name) ? $jsonObj->name : '';
    $email = !empty($jsonObj->email) ? $jsonObj->email : '';
    $coupon_id = !empty($jsonObj->coupon_id) ? $jsonObj->coupon_id : '';

    // Fetch plan details from the database 
    $sqlQ = "SELECT * FROM plans WHERE id=?";
    $stmt = $db->prepare($sqlQ);
    $stmt->bind_param("i", $db_id);
    $db_id = $subscr_plan_id;
    $stmt->execute();
    $result = $stmt->get_result();
    $planData = $result->fetch_assoc();

    $planName = $planData['name'];
    $planPrice = $planData['us_main_p'];
    $planInterval = $planData['interval'];

    // Fetch plan details from the database 
    $query_s = $db->query(" SELECT * FROM `discount`");

    $totalValue = $planData['us_main_p'];
    $price = $planPrice;
    $count = $count_site;
    

    $planPrice =  $totalValue;

    $planPrice = !empty($jsonObj->t_Price) ? $jsonObj->t_Price : $planPrice;
 

    // Convert price to cents 
    $planPriceCents = round($planPrice * 100);

    // Add customer to stripe 
    try {
        $customer = \Stripe\Customer::create([
            'name' => $name,
            'email' => $email
        ]);
    } catch (Exception $e) {
        $api_error = $e->getMessage();
    }

    if (empty($api_error) && $customer) {
        try {
            // Create price with subscription info and interval 
            $price = \Stripe\Price::create([
                'unit_amount' => $planPriceCents,
                'currency' => STRIPE_CURRENCY,
                'recurring' => ['interval' => $planInterval],
                'product_data' => ['name' => $planName],
            ]);
        } catch (Exception $e) {
            $api_error = $e->getMessage();
        }

        if (empty($api_error) && $price) {
            // Create a new subscription 
            try {

                if($coupon_id!=""){
                        $subscription = \Stripe\Subscription::create([
                            'customer' => $customer->id,
                            'items' => [[
                                'price' => $price->id,
                            ]],
                            'payment_behavior' => 'default_incomplete',
                            'expand' => ['latest_invoice.payment_intent'],
                            'description' => "Subscription Created",
                            'coupon' => $coupon_id,
                             
                        ]);
                }
                else{
                        $subscription = \Stripe\Subscription::create([
                            'customer' => $customer->id,
                            'items' => [[
                                'price' => $price->id,
                            ]],
                            'payment_behavior' => 'default_incomplete',
                            'expand' => ['latest_invoice.payment_intent'],
                            'description' => "Subscription Created",
                        ]);                    
                }



            } catch (Exception $e) {
                $api_error = $e->getMessage();
            }

            if (empty($api_error) && $subscription) {
                $output = [
                    'subscriptionId' => $subscription->id,
                    'clientSecret' => $subscription->latest_invoice->payment_intent->client_secret,
                    'customerId' => $customer->id
                ];

                echo json_encode($output);
            } else {

                if (str_contains($api_error, 'is used up and cannot be applied')) { 
                        echo json_encode(['error' => "Coupon is used up and cannot be applied."]);
                }else{
                        echo json_encode(['error' => $api_error]);
                  }
            }
        } else {
            echo json_encode(['error' => $api_error]);
        }
    } else {
        echo json_encode(['error' => $api_error]);
    }
} elseif ($jsonObj->request_type == 'payment_insert') {
    $payment_intent = !empty($jsonObj->payment_intent) ? $jsonObj->payment_intent : '';
    $subscription_id = !empty($jsonObj->subscription_id) ? $jsonObj->subscription_id : '';
    $customer_id = !empty($jsonObj->customer_id) ? $jsonObj->customer_id : '';
    $subscr_plan_id = !empty($jsonObj->subscr_plan_id) ? $jsonObj->subscr_plan_id : '';
    $t_Price = !empty($jsonObj->t_Price) ? $jsonObj->t_Price : '';
    $tax_price = !empty($jsonObj->tax_price) ? $jsonObj->tax_price : '';
    $coupon_id = !empty($jsonObj->coupon_id) ? $jsonObj->coupon_id : '';

 

    // Fetch plan details from the database 
    $sqlQ = "SELECT * FROM plans WHERE id=?";
    $stmt = $db->prepare($sqlQ);
    $stmt->bind_param("i", $db_id);
    $db_id = $subscr_plan_id;
    $stmt->execute();
    $result = $stmt->get_result();
    $planData = $result->fetch_assoc();

    $planName = $planData['name'];
    $planPrice = $planData['us_main_p'];
    $planInterval = $planData['interval'];



    // Retrieve customer info 
    try {
        $customer = \Stripe\Customer::retrieve($customer_id);
    } catch (Exception $e) {
        $api_error = $e->getMessage();
    }

    // Check whether the charge was successful 
    if (!empty($payment_intent) && $payment_intent->status == 'succeeded') {

        // Retrieve subscription info 
        try {
            $subscriptionData = \Stripe\Subscription::retrieve($subscription_id);
        } catch (Exception $e) {
            $api_error = $e->getMessage();
        }

 
        $payment_intent_id = $payment_intent->id;
        $paidAmount = $payment_intent->amount;
        $paidAmount = ($paidAmount / 100);
        $paidCurrency = $payment_intent->currency;
        $payment_status = $payment_intent->status;

        $created = date("Y-m-d H:i:s", $payment_intent->created);
        $current_period_start = $current_period_end = '';
        if (!empty($subscriptionData)) {
            $created = date("Y-m-d H:i:s", $subscriptionData->created);
            $current_period_start = date("Y-m-d H:i:s", $subscriptionData->current_period_start);
            $current_period_end = date("Y-m-d H:i:s", $subscriptionData->current_period_end);
        }

        $name = $email = '';
        if (!empty($customer)) {
            $name = !empty($customer->name) ? $customer->name : '';
            $email = !empty($customer->email) ? $customer->email : '';
        }

        // Check if any transaction data exists already with the same TXN ID 
        $sqlQ = "SELECT id FROM user_subscriptions WHERE stripe_payment_intent_id = ?";
        $stmt = $db->prepare($sqlQ);
        $stmt->bind_param("s", $db_txn_id);
        $db_txn_id = $payment_intent_id;
        $stmt->execute();
        $result = $stmt->get_result();
        $prevRow = $result->fetch_assoc();

        $payment_id = 0;
        if (!empty($prevRow)) {
            $payment_id = $prevRow['id'];
        } else {

            $sqlQ = "SELECT count(id)as count FROM user_subscriptions WHERE user_id = $userID";
            $stmt = $db->prepare($sqlQ);
            $stmt->execute();
            $result = $stmt->get_result();
            $prevRow1 = $result->fetch_assoc();
            $site_count_dd = 0;
            if (!empty($prevRow1)) {
                $site_count_dd = $prevRow1['count'];
            }
            // echo '<br>aa';
            // die;
             $sid_id = $jsonObj->sid_id;

            $sqlQ1 = "SELECT id,subscription_id FROM boost_website WHERE manager_id = $userID and id = '$sid_id' and plan_type = 'Free' ";
            $stmt = $db->prepare($sqlQ1);
            $stmt->execute();
            $result1 = $stmt->get_result();
            $prevRow1 = $result1->fetch_assoc();
            $site_free = 0;
            
            if (!empty($prevRow1)) {
                $site_free = 1;
                 
            }

            $sqlQ2 = "SELECT id,subscription_id FROM boost_website WHERE manager_id = $userID and id = '$sid_id'";
            $stmt = $db->prepare($sqlQ2);
            $stmt->execute();
            $result2 = $stmt->get_result();
            $prevRow1 = $result2->fetch_assoc();
            
            $sub_id = '';
            if (!empty($prevRow1)) {
                
                $sub_id = $prevRow1['subscription_id'];
            }

            $discount_price = 0;
            if($coupon_id!="")
            {
                $discount_price = $t_Price - $paidAmount;
            }

            // Insert transaction data into the database 
            $sqlQ = "INSERT INTO user_subscriptions (user_id,plan_id,stripe_subscription_id,stripe_customer_id,stripe_payment_intent_id,paid_amount,total_tax,discount_amount,discount_code_id,plan_price,paid_amount_currency,plan_interval,payer_email,created,plan_period_start,plan_period_end,status,subscription_items_id,products_id,json_data,site_count) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
            $stmt = $db->prepare($sqlQ);
            $stmt->bind_param("iisssdsssssssssssssss", $db_user_id, $db_plan_id, $db_stripe_subscription_id, $db_stripe_customer_id, $db_stripe_payment_intent_id, $db_paid_amount, $db_paid_total_tax, $bd_discount_amount,$db_discount_code_id, $db_paid_total_price, $db_paid_amount_currency, $db_plan_interval, $db_payer_email, $db_created, $db_plan_period_start, $db_plan_period_end, $db_status, $subscription_items_id, $products_id, $json_data, $site_count);
            $db_user_id = $userID;
            $db_plan_id = $subscr_plan_id;
            $db_stripe_subscription_id = $subscription_id;
            $db_stripe_customer_id = $customer_id;
            $db_stripe_payment_intent_id = $payment_intent_id;
            $db_paid_amount = $paidAmount;
            $db_paid_total_tax = $tax_price;

            $bd_discount_amount = $discount_price;
            $db_discount_code_id = $coupon_id;

            $db_paid_total_price = $t_Price;
            $db_paid_amount_currency = $paidCurrency;
            $db_plan_interval = $planInterval;
            $db_payer_email = $email;
            $db_created = $created;
            $db_plan_period_start = $current_period_start;
            $db_plan_period_end = $current_period_end;
            $db_status = $payment_status;
            $subscription_items_id = $subscriptionData->items->data[0]->id;
            $products_id = $subscriptionData->plan->product;
            $json_data = json_encode($subscriptionData);
            $site_count = $count_site;
            $insert = $stmt->execute();

            if ($insert) {
                $payment_id = $stmt->insert_id;

                // ------------------------------------



                // ------------------------------------
                    $sql_update_c = " UPDATE coupons SET number_of_uses = 1, status = 2 where strip_coupon_id='$coupon_id' ";
                    $stmt_c = $db->prepare($sql_update_c);
                    $update_c = $stmt_c->execute();          

                // if ($site_count_dd == 0) {
                 $sql_update = " UPDATE boost_website SET plan_id = $db_plan_id, plan_type = 'Subscription',subscription_id= '$payment_id' where manager_id='$db_user_id' and id = '$sid_id' ";
                    $stmt = $db->prepare($sql_update);
                    $update = $stmt->execute();
                    $stmt = $db->prepare($sql_update);
                    $update = $stmt->execute();

                    if($site_free ==1){
                    $sql_update = " UPDATE user_subscriptions_free SET status = 0 where user_id='$db_user_id' ";
                    $stmt = $db->prepare($sql_update);
                    $update = $stmt->execute();
                }
            // }



                $user_idss = $_SESSION['user_id'];
                $change_id = $jsonObj->change_id;
              


                //This Process is For Change the Plan
                if (!empty($change_id)) {

                    // Update The Booster Table Because The Content oF THE oREVIOUS ONE Save To new One 
                    $sqlzz = "SELECT * FROM user_subscriptions WHERE stripe_subscription_id = '$subscription_id' and user_id = '$userID'";
                    // die;
                    $stmtzz = $db->prepare($sqlzz);
                    $stmtzz->execute();
                    $resultzz = $stmtzz->get_result();
                    $fetchRow = $resultzz->fetch_assoc();
                    if (!empty($fetchRow)) {

                        $newSiteid = $fetchRow['id'];

                        $sqlC = "UPDATE boost_website SET subscription_id = '$newSiteid', plan_id = '$subscr_plan_id' where subscription_id= '$change_id'";
                        $stmtC = $db->prepare($sqlC);
                        $updateC = $stmtC->execute();
 

                    }

 
                    
                    $sqlQ = "SELECT * FROM user_subscriptions WHERE user_id = '$user_idss' and id = '$sub_id' and is_active = 1";
                    // die;
                    $stmt = $db->prepare($sqlQ);
                    $stmt->execute();
                    $result = $stmt->get_result();
                    $prevRow = $result->fetch_assoc();
                    if (!empty($prevRow)) {

                        $subscription = \Stripe\Subscription::retrieve($prevRow['stripe_subscription_id']);
                        // print_r($subscription);
                        $subscription->cancel();

                        $sqlx = "UPDATE user_subscriptions SET is_active = 0, cancled_at = now() where id = '$sub_id' ";
                        $stmtx = $db->prepare($sqlx);
                        $stmtx->execute();
                    }
                }
                // die;

                $sql_update_u = " UPDATE admin_users SET flow_step = 2 where id = '$user_idss' ";
                $stmtU = $db->prepare($sql_update_u);
                $updateu = $stmtU->execute();

                // card details save code ----------------------------------------------------------------
                $stripe = new \Stripe\StripeClient(STRIPE_API_KEY);
                $payment_intent_data = $stripe->paymentIntents->retrieve($payment_intent_id);
                $user_card_detail = $payment_intent_data->charges->data[0]->payment_method_details->card;
                // echo "here";
                // print_r($user_card_detail) ;

                $cardnumber = $user_card_detail->last4;
                $cardnumber = "************" . $cardnumber;
                $exp_month = $user_card_detail->exp_month;
                $exp_year = $user_card_detail->exp_year;
                $cvc = '';

                $sql_update = " UPDATE payment_method_details SET prefered_card = 0 where manager_id = '$userID' ";
                $stmt = $db->prepare($sql_update);
                $update = $stmt->execute();

                // 

                $sql = "SELECT * FROM `payment_method_details` where card_number LIKE '" . "%" . substr($cardnumber, -4, 4) . "' AND exp_month LIKE '" . "%" . $exp_month . "' AND exp_year LIKE  '" . "%" . $exp_year . "' AND card_name LIKE '" . "%" . $name . "' AND manager_id = '$userID'";
                $payment_method_row = $db->query($sql);

                if (($payment_method_row->num_rows) <= 0) {
                    $sql_insert = " INSERT INTO payment_method_details ( manager_id , card_name , card_number , exp_month , exp_year , cvv ,  prefered_card ) VALUES ( ? , ? , ? , ? , ? , ? , ? ) ";
                    $stmt = $db->prepare($sql_insert);
                    $stmt->bind_param("sssssss", $db_user_id, $name, $cardnumber, $exp_month, $exp_year, $cvc, $prefered_card);
                    $db_user_id = $userID;
                    $name = $name;
                    $cardnumber = $cardnumber;
                    $exp_month = $exp_month;
                    $exp_year = $exp_year;
                    $cvc = $cvc;
                    $prefered_card = 1;

                    $insert = $stmt->execute();
                }else{

                    $id_payment=$payment_method_row->fetch_assoc()['id'];
                    // echo $id_payment;
                   $update_sql= "UPDATE `payment_method_details` SET prefered_card=1 WHERE  id='$id_payment' and manager_id = '$userID'";
                    // echo $update_sql;

                   $db->query($update_sql);

 
                }
 

            }
  

        }

        $output = [
            'payment_id' => base64_encode($payment_id)
        ];
        echo json_encode($output);
    } else {
        echo json_encode(['error' => 'Transaction has been failed!']);
    }
}
