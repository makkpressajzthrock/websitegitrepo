<?php 
/* Stripe API configuration 
 * Remember to switch to your live publishable and secret key in production! 
 * See your keys here: https://dashboard.stripe.com/account/apikeys 
 */ 
// define('STRIPE_API_KEY', ''); 
// define('STRIPE_PUBLISHABLE_KEY', ''); 
// define('STRIPE_CURRENCY', 'USD'); 
  
// Database configuration  
define('DB_HOST', 'localhost'); 
define('DB_USERNAME', 'root'); 
define('DB_PASSWORD', 'makkpress@123A'); 
define('DB_NAME', 'websitesecondphase');
