<?php 


require_once("../adminpannel/config.php") ;
require_once('../adminpannel/inc/functions.php') ;
$state_id=$_POST['state_id'];
$city_id=$_POST['city_id'];

if (isset($_POST['state_id'])) {
	 $data_state=getTableData( $conn , "list_states" , "countryId='$state_id'" ,"",1) ;
	 foreach ($data_state as $key => $value) {
	               echo "<option value='".$value['id']."'>".$value['statename']."</option>";
	 	// code...
	 }

}
if (isset($_POST['city_id'])) {
	 $data_city=getTableData( $conn , "list_cities" , "state_id='$city_id'" ,"",1) ;
	 foreach ($data_city as $key => $value) {
	               echo "<option value='".$value['id']."'>".$value['cityName']."</option>";
	 	// code...
	 }

}