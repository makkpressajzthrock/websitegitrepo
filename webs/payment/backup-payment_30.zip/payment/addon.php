<?php 
session_start();
 include('../adminpannel/session.php');

// Include configuration file  
require_once 'config.php'; 
 
// Include the database connection file 
include_once 'dbConnect.php'; 

require_once("../adminpannel/config.php") ;
require_once('../adminpannel/inc/functions.php') ;

require_once("Common.php") ;


if(isset($_SESSION['user_id']) && !empty($_SESSION["user_id"]))
{}
else{
 if (isset($_SERVER["HTTP_REFERER"])) {
        $_SESSION['error'] = "Plan Not loading please try again.";
        header("Location: " . $_SERVER["HTTP_REFERER"]);

        die;
    }
}

  $id = base64_decode($_GET['id']) ;
  $sid = base64_decode($_GET['sid']) ;

$row = getTableData( $conn , " admin_users " , " id ='".$_SESSION['user_id']."' AND userstatus LIKE '".$_SESSION['role']."' " ) ;
$addon = getTableData( $conn , " addon " , " id ='$id' " ) ;

$site_id = getTableData( $conn , " boost_website " , " id ='$sid' " ) ;

$subscription = $site_id['subscription_id'];

$user_subscriptions = getTableData( $conn , " user_subscriptions " , " id ='$subscription' " ) ;
$customer = $user_subscriptions['stripe_customer_id'];

$total_price = $addon['price'];

$fName = $row['firstname'];
$email = $row['email'];

?>

<script src="https://js.stripe.com/v3/"></script>
<script src="js/checkout_addon.js" STRIPE_PUBLISHABLE_KEY="<?php echo STRIPE_PUBLISHABLE_KEY; ?>" defer></script>
<link rel="stylesheet" type="text/css" href="css/style.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.3/jquery.min.js" integrity="sha512-STof4xm1wgkfm7heWqFJVn58Hm3EtS31XFaagaa8VMReCXAkQnJZ+jEy8PCC/iT18dFy95WcExNHFTqLyp72eQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<div class="payment_addon_s_wrapper">
<div class="payment_addon_s">
<div class="glass"></div>
		<div class="glass"></div>
		<div class="glass"></div>
		<div class="glass"></div>
		<div class="glass"></div>
		<div class="glass"></div>
		<div class="glass"></div>
		<div class="glass"></div>
<div class="container">
<?php 


  ?>

        <div class="logo-cus"><img src="https://ecommerceseotools.com/ecommercespeedy/adminpannel/img/sitelogo.png" alt="Ecommercespeedy Logo"></div>
    <div class="panel-heading">
        <h3 class="panel-title">Subscription with Stripe</h3>
        
        <div class="payble_amt">Payble Amount: <?php echo  '$ '.$total_price; ?></div>
        <br>
        <!-- Plan Info -->
        <div style="display: none;">
            <b>Select Plan:</b>
             

        </div>
    </div>
    <div class="panel-body">
        <!-- Display status message -->
        <div id="paymentResponse" class="hidden"></div>
     
        <!-- Display a subscription form -->
        <form id="subscrFrm">
             

            <div class="form-group">
                <label>NAME</label>
                <input type="text" id="name" class="form-control" value="<?php echo $fName; ?>" placeholder="Enter name" required="" autofocus="">
            </div>
            <div class="form-group">
                <label>EMAIL</label>
                <input type="email" id="email" class="form-control" value="<?php echo $email; ?>" placeholder="Enter email" required="">
            </div>
            
            <div class="form-group">
                <label>CARD INFO</label>
                <div id="card-element" class="form-control">
                    <!-- Stripe.js will create card input elements here -->
                </div>
            </div>
            


             <div class="form-group">
                <input type="hidden" id="subscr_plan" class="form-control" value="<?php echo $id; ?>"  >
                <input type="hidden" id="t_Price" class="form-control" value="<?php echo $total_price; ?>"  >
                <input type="hidden" id="customer_id" class="form-control" value="<?php echo $customer; ?>"  >
                <input type="hidden" id="site_id" class="form-control" value="<?php echo $sid; ?>"  >
            </div>

            <!-- Form submit button -->
            <button id="submitBtn" class="btn btn-success">
                <div class="spinner hidden" id="spinner"><svg xmlns:svg="http://www.w3.org/2000/svg" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.0" width="160px" height="20px" viewBox="0 0 128 16" xml:space="preserve"><path fill="#949494" d="M6.4,4.8A3.2,3.2,0,1,1,3.2,8,3.2,3.2,0,0,1,6.4,4.8Zm12.8,0A3.2,3.2,0,1,1,16,8,3.2,3.2,0,0,1,19.2,4.8ZM32,4.8A3.2,3.2,0,1,1,28.8,8,3.2,3.2,0,0,1,32,4.8Zm12.8,0A3.2,3.2,0,1,1,41.6,8,3.2,3.2,0,0,1,44.8,4.8Zm12.8,0A3.2,3.2,0,1,1,54.4,8,3.2,3.2,0,0,1,57.6,4.8Zm12.8,0A3.2,3.2,0,1,1,67.2,8,3.2,3.2,0,0,1,70.4,4.8Zm12.8,0A3.2,3.2,0,1,1,80,8,3.2,3.2,0,0,1,83.2,4.8ZM96,4.8A3.2,3.2,0,1,1,92.8,8,3.2,3.2,0,0,1,96,4.8Zm12.8,0A3.2,3.2,0,1,1,105.6,8,3.2,3.2,0,0,1,108.8,4.8Zm12.8,0A3.2,3.2,0,1,1,118.4,8,3.2,3.2,0,0,1,121.6,4.8Z"/><g><path fill="#949494" d="M-42.7,3.84A4.16,4.16,0,0,1-38.54,8a4.16,4.16,0,0,1-4.16,4.16A4.16,4.16,0,0,1-46.86,8,4.16,4.16,0,0,1-42.7,3.84Zm12.8-.64A4.8,4.8,0,0,1-25.1,8a4.8,4.8,0,0,1-4.8,4.8A4.8,4.8,0,0,1-34.7,8,4.8,4.8,0,0,1-29.9,3.2Zm12.8-.64A5.44,5.44,0,0,1-11.66,8a5.44,5.44,0,0,1-5.44,5.44A5.44,5.44,0,0,1-22.54,8,5.44,5.44,0,0,1-17.1,2.56Z"/><animateTransform attributeName="transform" type="translate" values="23 0;36 0;49 0;62 0;74.5 0;87.5 0;100 0;113 0;125.5 0;138.5 0;151.5 0;164.5 0;178 0" calcMode="discrete" dur="1170ms" repeatCount="indefinite"/></g></svg></div>
                <span id="buttonText">Proceed</span>
            </button>
        </form>
        
        <!-- Display processing notification -->
        <div id="frmProcess" class="hidden">
            <span class="ring"></span> Processing...
        </div>
    </div>
</div>
</div>
</div>

